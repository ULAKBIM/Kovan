Bu dosya FreeBSD 8 ve 8.1 AMD64 Surumu icin Kovan yaziliminin nasil 
kurulacagi ile ilgili bilgiler icermektedir.
Belge asagidaki kisimlardan olusmaktadir.



1. FreeBSD'nin Kovan kurulumu icin hazirlanmasi
   a) FreeBSD kaynak kodlarinin guncellenmesi (Opsiyonel)
   b) Cekirdege VIMAGE desteginin verilmesi (Zorunlu)
   c) Cekirdegin derlenmesi (Zorunlu)
   d) FreeBSD sisteminin port agacinin guncel hale getirlmesi (Opsiyonel)
   e) IPv6  & IPv6  yonlendirme desteginin acilmasi acilmasi (Zorunlu)
   f) IPC ayarlarinin yapilmasi (Zorunlu)

2. Monitor, Router, Client Jail  kurulumu
3. Kovan kurulumu
4. Kovan Yapilandirmasi
   a) Kovan Monitor Makinesinin Yapilandirilmasi (Opsiyonel)



1. FreeBSD'nin  Kovan kurulumu icin hazirlanmasi
================================================

   a) FreeBSD kaynak kodlarinin guncellenmesi (Opsiyonel)
   FreeBSD Kaynak Kodlarinin guncellenmesi icin cvsup komutunu kullanabilirsiniz 
   bunun icin 

	 pkg_add -r cvsup-without-gui

   komutu ile cvsup programi yukledikten sonra,kaynak kodlarin guncellenmesi icin 
   asagidaki satirlari /etc/stable.supfile dosyasina ekleyin

	*default host=tulumba.ulakbim.gov.tr
	*default base=/usr
	*default prefix=/usr
	*default release=cvs tag=RELENG_8_1
	*default delete use-rel-suffix

	src-all

   daha sonra 

	cvsup /etc/stable-supfile 

   komutunu kullanarak kaynak kodlarinizi guncelleyebilirsiniz 

   b) Cekirdege VIMAGE desteginin verilmesi (Zorunlu)

   VIMAGE desteginin verilebilmesi icin asagidaki satiri  cekirdek yapilandirma
   dosyaniza (/usr/src/sys/amd64/conf/GENERIC) eklemeniz gerekiyor.
    
	options VIMAGE

   Bununla birlikte VIMAGE ile birlite SCTP  destegi FreeBSD 8'de sorunlu 
   oldugu icin FreeBSD 8 kullniyorsaniz derleme sirasinda asagidaki hata ile 

	SCPT is not yet compatible with VIMAGE

    karsilastigini icin cekirdek yapilandirma dosyanizin icinde asaidaki satiri
    silmeniz veya basina # eklemeniz gerekiyor.FreeBSD 8.1 icin bu degisiklige
    gerek yok.

	options  SCTP

   c) Cekirdegin derlenmesi (Zorunlu) 

   	cd /usr/src/sys/amd64/conf
	config GENERIC
	cd ../compile/GENERIC/
	make cleandepend && make depend && make && make install

   Cekirdek derleme islenminden sonra istetim sistemin yeniden baslatmaniz
   gerekmektedir.
		
   d) FreeBSD sisteminin port agacinin guncel hale getirlmesi (Opsiyonel) 
   
   FreeBSD port agacinin guncellenmesi icin portsnap komutu kullanilabilir

	portsnap -s portsnap2.freebsd.org fetch
	portsnap extract

   Update komutuun her gece 12:30'da otomatik olarak calismasi icin asagidaki
   satir  cron'a eklenebilir

	30 12 * * * /usr/sbin/portsnap update

   Diger bir yontem "FreeBSD kaynak kodlarinin guncellenmesi" kisminda anlatilan 
   sekilde cvsup programinin kurularak /etc/stable-supfile dosyasinin ports-all
   satirinida icericek sekilde asagidaki sekilde duzenlenmesi olabilir. 

	*default host=tulumba.ulakbim.gov.tr
        *default base=/usr
        *default prefix=/usr
        *default release=cvs tag=RELENG_8_1
        *default delete use-rel-suffix

        src-all
	ports-all tag=.


  e)IPv6 & IPv6  yonlendirme desteginin acilmasi acilmasi (Zorunlu)

   Asagidaki satiri /etc/rc.conf dosyasina ekleyin

	ipv6_enable="YES"

  Asagidaki satirlari /etc/sysctl.conf dosyasina ekeyin

	net.inet.ip.forwarding=1
	net.inet6.ip6.forwarding=1
	security.jail.allow_raw_sockets=1

 f) IPC ayarlarinin yapilmasi
  Asagidaki satirlari /boot/loader.conf dosyasinin altina yazin (Sistem
  reboot oldugunda etkin hale gelecektir)

	kern.ipc.shmall=32768
	kern.ipc.shmmax=134217728
	kern.ipc.semmap=256
	kern.ipc.semmni=256
	kern.ipc.semmns=512
	kern.ipc.semmnu=256


SHMALL	Total amount of shared memory available (bytes or pages) 	if bytes, same as SHMMAX; if pages, ceil(SHMMAX/PAGE_SIZE)
SHMMAX	Maximum size of shared memory segment (bytes)			at least several megabytes (see text)
SEMMAP	Number of entries in semaphore map	
SHMMNI	Maximum number of shared memory segments system-wide		like SHMSEG plus room for other applications
SEMMNS	Maximum number of semaphores system-wide			ceil(max_connections / 16) * 17 plus room for other applications
SHMMIN	Minimum size of shared memory segment (bytes)			

2. Monitor, router, client jail kurulumu
========================================
   Kovan  tarafinda kullanilan sanal ag altyapisinin calismasi icin FreeBSD
   ezjail portu kullanilmaktadir. Portu kurmak icin asagidaki komutlarin
   yazilmasi yeterlidir.

	cd /usr/ports/sysutils/ezjail
	make -DBATCH install clean

  Bundan sonraki asamada basejail  kurumlu icin asagidaki komut calistirilmalidir.

	ezjail-admin install
    
	
 Bu portlari kur

	cd /usr/ports/lang/perl5.10 && make -DBATCH install clean
	cd /usr/ports/textproc/p5-YAML-Tiny/ &&   make -DBATCH    install clean 
	cd /usr/ports/devel/p5-Getopt-Long &&   make -DBATCH  install clean 

 
3. Kovan kurulumu
========================================

cd kovan_host
make 
make install

cd kovan_jail
make 
make install

4. Kovan Yapilandirmasi
========================================

### BURADA install.sh kullanimini yaz
###   kvnHost_ng.conf altinda asagidaki satirlari degistir

quagga_dir_host: /usr/local/kovan/router/usr/local/etc/quagga
quagga_dir_jail: /usr/local/etc/quagga
physical_ether: bce0
kovan_dir: /usr/local/kovan 

 
 #### SERIVLER NASIL BASLATILCAK mrtg. snmp. balkupu servisleri nfsen  

	a) Kovan Monitor Makinesinin Yapilandirilmasi (Opsiyonel)

    -Kovan Kurulum sirasinda 3 adet sanal tip router, node, monitor
    -Bu adimlarin yapilabilmesi icin Kovan yapilandirma dosyasinda monitor
    tipi icin sanal bilgisayar olusturulmalidir  
    -Ayrica Mrtg'nin yapilandirmasinin calismasi icin  Kovan calistirilmis olmali

    Apache
    
	./apachePhpCreate -f ../etc/kvnHost_ng.conf --install
	./apachePhpCreate -f ../etc/kvnHost_ng.conf --configure

    Nfsen
	./nfsenCreate -f ../etc/kvnHost_ng.conf --install
	./nfsenCreate -f ../etc/kvnHost_ng.conf --configure
	./nfsenCreate -f ../etc/kvnHost_ng.conf --run
	
    Mrtg
	 ./mrtgCreate -f ../etc/kvnHost_ng.conf --install

        #Configure Komutunda Ekrana Hata satirlari basacak bu mrtg ilk kez
        calistigi icin normal

	./mrtgCreate -f ../etc/kvnHost_ng.conf --configure
	./mrtgCreate -f ../etc/kvnHost_ng.conf --run 


	En son olarak Apache'yi baslatalim

	./apachePhpCreate -f ../etc/kvnHost_ng.conf --run     

 





##### Portslari mount et
mkdir -p  /usr/local/kovan/router
rm 	/usr/local/kovan/router/usr/ports

mkdir -p /usr/local/kovan/router/usr/ports
mount_nullfs -o ro /usr/ports /usr/local/kovan/monitor/usr/ports

############### QEMU VNET   ######
 cd /usr/ports/emulators/qemu
make -DBATCH install clean

cd /usr/ports/emulators/kqemu-kmod
make -DBATCH install clean 

kldload kqemu
kldload aio

### jailleri ac

ifconfig bridge create
#bridge1

ifconfig epair create
#epair1a
ifconfig epair1a vnet comuh
ifconfig bridge1 addm epair1b 


ifconfig tap create
ifconfig bridge1 addm tap0
 ifconfig bridge1 up
ifconfig epair1b up
jexec comuh ifconfig epair1a up
jexec comuh ifconfig epair1a 10.10.80.1 netmask 255.255.255.0 up

ifconfig bridge1 up
ifconfig tap0 up
qemu-system-x86_64 -m 256  -net nic -net tap,name=tap0, -hda nfsen.calisan.img -boot c -vnc :1

